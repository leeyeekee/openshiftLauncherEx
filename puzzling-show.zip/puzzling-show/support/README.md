# welcome-app

Created by the Cloud App Generator

Now that the application has been generated it can be deployed in the currently active project on OpenShift by going into the
project folder and running:

```
$ ./gap deploy
```
